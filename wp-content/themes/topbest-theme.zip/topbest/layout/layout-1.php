		<?php get_template_part('slider'); ?>


        <!-- MAIN CONTENT -->
        <div id="outermain">
        	<div class="container">
                <div class="row">
                	<section id="maincontent" class="twelve columns">
                    
                        <section class="content">
                        
                        		<?php get_template_part('layout/template/services') ?>
                        		
                                <?php get_template_part('layout/template/recent-portfolio-2') ?>
                                
                                <?php get_template_part('layout/template/recent-blog') ?>
                            
                        </section>
                    
                	</section>
                </div>
            </div>
        </div>
        <!-- END MAIN CONTENT -->