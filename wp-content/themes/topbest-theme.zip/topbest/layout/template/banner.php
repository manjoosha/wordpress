<?php if( vp_option('banner_enable') == '1') { ?>

<div class="headline">
<h1><?php echo vp_option('banner_text'); ?></h1>
</div>

<?php } ?>